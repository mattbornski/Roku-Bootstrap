This executable uses the boost shared libraries from mac ports

To install the boost shared libraries, goto http://www.macports.org/install.php and install the mac ports project. Then from a shell prompt, install boost by running:

% sudo port install boost

Then put biftool in your path


