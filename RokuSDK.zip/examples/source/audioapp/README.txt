AudioApp is a program that demonstrates the use of 
roSpringboard and roAudioPlayer.

It contains 3 categories:
1. NPR - demonstrate a live news feed
2. MP3 - demonstrates playing of various mp3 audio files
3. WMA - demonstrates playing of various wma audio files

you can pause, resume, start, and stop the audio.

Thanks to Jeremiah Jones for access to his 
recorded piano playing.
