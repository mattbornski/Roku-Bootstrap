DeviantArt is a program that demonstrates 
the use of roSlideshow and roAudioPlayer.

The audioplayer is used very simply in a 
loop playing the same songs over and over 
while displaying slides from two of the 
deviantArt channels. It makes use of the 
rssfeed available from deviantArt.

See www.deviantArt.com for more information

