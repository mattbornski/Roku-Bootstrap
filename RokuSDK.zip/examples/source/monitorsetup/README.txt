MonitorSetup is a program that demonstrates the 
use of roSlideshow.

It contains a series of images in different 
resolutions that help check out your display 
performance.  There are pictures for convergence, 
linearity, overscan, and color, as well as some 
historical images used by the broadcast industry.
