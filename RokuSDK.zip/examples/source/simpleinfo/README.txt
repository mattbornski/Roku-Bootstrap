The simpleinfo application shows how to the
roMessageDialog with overlay over a roPosterScreen.
It shows a poster screen with a filter banner of
categories. It is a modification of the simple
poster example. When the focus is on the center
poster InfoButton presses can be detected and used
to bring up the messagedialog to describe and
allow the user select options or actions.
It's a minimalist application, designed to just
show how to set up this screen type.
